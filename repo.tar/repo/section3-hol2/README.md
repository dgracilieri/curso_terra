#The Terraform code in this folder is for use with an A Cloud Guru , Hands-on Lab
#The main.tf file contains the resource for creating EC2 instance using a Provisioner
#The setup.tf file sets up all the ancillary resources needed by the EC2 instance before it 
#can be spun up.
