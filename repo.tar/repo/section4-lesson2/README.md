#This folder houses an example of spinning up docker container
#using the docker provider in Terraform

#It is part of the ACG course for Terraform Associate Certification

#Users will need to have docker configured properly so that Terraform 
#can interface with and deploy resources using docker
